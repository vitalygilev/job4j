[![Build Status](https://travis-ci.org/vitalygilev/job4j.svg?branch=master)](https://travis-ci.org/vitalygilev/job4j)
[![codecov](https://codecov.io/gh/vitalygilev/job4j/branch/master/graph/badge.svg)](https://codecov.io/gh/vitalygilev/job4j)


# job4j
# Hi! Here I've made some changes!
Тут я опять что-то там изменяю...

Объединение зафиксированных изменений.

Создаем ветку.

Создаем ветку из IDEA
