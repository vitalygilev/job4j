package ru.job4j.oop;

public class Ball {
    public void tryEat(Ball ball) {
        System.out.println("Very strange situation. Ball tries to eat himself!");
    }
}
