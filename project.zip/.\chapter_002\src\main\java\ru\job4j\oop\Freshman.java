package ru.job4j.oop;

public class Freshman extends Student {

    private String group;

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }
}
