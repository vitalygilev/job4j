package ru.job4j.oop;

public class Animal {

    public String name;

    public Animal(String name) {
        this.name = name;
        System.out.println(this.name);
    }

}
