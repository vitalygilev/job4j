package ru.job4j.pseudo;

public interface Shape {
    String draw();
}
