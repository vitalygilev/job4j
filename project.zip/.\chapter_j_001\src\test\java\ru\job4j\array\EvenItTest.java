package ru.job4j.array;

import junit.framework.TestCase;

public class EvenItTest extends TestCase {

}