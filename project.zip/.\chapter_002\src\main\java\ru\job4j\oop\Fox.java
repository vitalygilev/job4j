package ru.job4j.oop;

public class Fox {
    public void tryEat(Ball ball) {
        System.out.println("Candidate Fox! We have a winner (brazen red muzzle)!!");
    }
}
