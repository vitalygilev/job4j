
/**
 * Package for calculate task.
 *
 * @author Vitaly Gilev (vitvit1@yandex.ru)
 * @version 1
 * @since 10.10.2019
*/
package ru.job4j.calculator;

